(function($){
	$(document).ready(function() { 	
		$('select.materialize_me').material_select();
		Materialize.updateTextFields();
	});
})(jQuery);
