# Instruction to Setup and Run Webpack

- If you don't have **node** then install [node](https://nodejs.org/en/download/).
- Open Terminal/Commmand and run **npm install webpack --save-dev**

You are ready to use webpack for this project.

# Build command
*npm run build*

# Watch command 
*npm run dev*