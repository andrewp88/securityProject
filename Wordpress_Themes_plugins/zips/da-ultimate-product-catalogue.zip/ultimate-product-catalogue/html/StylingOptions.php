<?php


?>

<div class="UPCPMenu">
	<h2 class="upcp-styling-mainmenu">
		<a id="ThumbnailView_Menu" class="MenuTab nav-tab <?php if ($Display_Page == '' or $Display_Page == 'Dashboard') {echo 'nav-tab-active';}?>" onclick="ShowTab('Dashboard');">Dashboard</a>
		<a id="ThumbnailView_Menu" class="MenuTab nav-tab <?php if ($Display_Page == '' or $Display_Page == 'Dashboard') {echo 'nav-tab-active';}?>" onclick="ShowTab('Dashboard');">Dashboard</a>
	</h2>
	<h2 class="upcp-styling-submenu" id='upcp-main-catalogue-styling-menu'>
		<a id="ThumbnailView_Menu" class="MenuTab nav-tab <?php if ($Display_Page == '' or $Display_Page == 'Dashboard') {echo 'nav-tab-active';}?>" onclick="ShowTab('Dashboard');">Dashboard</a>
		<a id="ListView_Menu" class="MenuTab nav-tab <?php if ($Display_Page == '' or $Display_Page == 'Dashboard') {echo 'nav-tab-active';}?>" onclick="ShowTab('Dashboard');">Dashboard</a>
		<a id="DetailView_Menu" class="MenuTab nav-tab <?php if ($Display_Page == '' or $Display_Page == 'Dashboard') {echo 'nav-tab-active';}?>" onclick="ShowTab('Dashboard');">Dashboard</a>
		<a id="Sidebar_Menu" class="MenuTab nav-tab <?php if ($Display_Page == 'Products') {echo 'nav-tab-active';}?>" onclick="ShowTab('Products');">Products</a>
		<a id="Pagination_Menu" class="MenuTab nav-tab <?php if ($Display_Page == 'Catalogues') {echo 'nav-tab-active';}?>" onclick="ShowTab('Catalogues');">Catalogues</a>
	</h2>
	<h2 class="upcp-styling-submenu" id='upcp-product-pages-styling-menu'>
		<a id="DefaultPP_Menu" class="MenuTab nav-tab <?php if ($Display_Page == '' or $Display_Page == 'Dashboard') {echo 'nav-tab-active';}?>" onclick="ShowTab('Dashboard');">Dashboard</a>
		<a id="CustomPP_Menu" class="MenuTab nav-tab <?php if ($Display_Page == '' or $Display_Page == 'Dashboard') {echo 'nav-tab-active';}?>" onclick="ShowTab('Dashboard');">Dashboard</a>
		<a id="TabbedPP_Menu" class="MenuTab nav-tab <?php if ($Display_Page == '' or $Display_Page == 'Dashboard') {echo 'nav-tab-active';}?>" onclick="ShowTab('Dashboard');">Dashboard</a>
		<a id="Sidebar_Menu" class="MenuTab nav-tab <?php if ($Display_Page == 'Products') {echo 'nav-tab-active';}?>" onclick="ShowTab('Products');">Products</a>
		<a id="Pagination_Menu" class="MenuTab nav-tab <?php if ($Display_Page == 'Catalogues') {echo 'nav-tab-active';}?>" onclick="ShowTab('Catalogues');">Catalogues</a>
	</h2>
</div>