<div class="snax-quiz-progress">
	<div class="snax-quiz-progress-track">
		<div class="snax-quiz-progress-bar" style="width: <?php echo (float) snax_get_percentage_result( 9 ); ?>%">
			<div class="snax-quiz-progress-value"><?php printf( esc_html__( '%.0f%%', 'snax' ), snax_get_percentage_result( 9 ) ); ?></div>
		</div>
	</div>
</div>