<div class="snax-quiz-intro-wrapper">

	<?php snax_get_template_part( 'quizzes/actions-start' ) ?>

</div>