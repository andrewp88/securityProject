<p class="snax-quiz-actions">
	<?php if ( snax_show_start_quiz_button() ) : ?>
		<button class="snax-quiz-button snax-quiz-button-start-quiz"><?php esc_html_e( 'Let\'s play', 'snax' ); ?></button>
	<?php endif; ?>
</p>

