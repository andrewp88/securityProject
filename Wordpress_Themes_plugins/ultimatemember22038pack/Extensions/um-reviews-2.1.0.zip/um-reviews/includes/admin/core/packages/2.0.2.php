<?php
if ( ! defined( 'ABSPATH' ) )
	exit; // Exit if accessed directly

UM()->Reviews_API()->api()->flush_reviews();