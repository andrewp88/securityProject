<div class="um-reviews-none">
	
	<?php echo ( um_is_myprofile() ) ? __('You have not received any reviews yet.','um-reviews') : __('This user did not receive any reviews yet.','um-reviews'); ?>
	
</div>