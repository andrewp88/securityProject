<div class="um-admin-metabox">

	<p><?php _e( 'Copy/paste the following shortcode to embed this social login anywhere on your site or within UM forms.', 'um-social-login' ); ?></p>
	
	<p><strong>[ultimatemember_social_login id=<?php echo get_the_ID(); ?>]</strong></p>
	
</div>