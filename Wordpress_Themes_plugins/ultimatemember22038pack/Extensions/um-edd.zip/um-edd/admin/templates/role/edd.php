<div class="um-admin-metabox">

	<div class="">
	
		<p>
			<label class="um-admin-half"><?php _e('Display purchases tab in profile?','um-edd'); ?></label>
			<span class="um-admin-half"><?php $this->ui_on_off( '_um_edd_downloads_tab', 1 ); ?></span>
		</p><div class="um-admin-clear"></div>
	
		<p>
			<label class="um-admin-half"><?php _e('Display orders under account?','um-edd'); ?></label>
			<span class="um-admin-half"><?php $this->ui_on_off( '_um_edd_account_orders', 1 ); ?></span>
		</p><div class="um-admin-clear"></div>
		
		<p>
			<label class="um-admin-half"><?php _e('Display billing address under account?','um-edd'); ?></label>
			<span class="um-admin-half"><?php $this->ui_on_off( '_um_edd_account_billing', 1 ); ?></span>
		</p><div class="um-admin-clear"></div>
		
	</div>
	
	<div class="um-admin-clear"></div>
	
</div>