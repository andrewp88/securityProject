<?php

	/***
	***	@When a specific product is bought
	***/
	add_action('edd_order_status_completed', 'um_edd_per_product_hook');
	function um_edd_per_product_hook( $order_id ) {
		global $ultimatemember;
		$order = new WC_Order( $order_id );
		$user_id = (int)$order->user_id;
		$items = $order->get_items();
		foreach ($items as $item) {
			$id = $item['product_id'];
			if ( get_post_meta( $id, '_um_edd_download_role', true ) != '' ) {
				um_fetch_user( $user_id );
				$ultimatemember->user->set_role( esc_attr( get_post_meta( $id, '_um_edd_download_role', true ) ) );
			}
		}
		return $order_id;
	}
	
	/***
	***	@When a specific product is cancelled
	***/
	add_action( 'edd_order_status_pending', 'um_edd_per_product_hook2' );
	add_action( 'edd_order_status_processing', 'um_edd_per_product_hook2' );
	add_action( 'edd_order_status_failed', 'um_edd_per_product_hook2' );
	add_action( 'edd_order_status_refunded', 'um_edd_per_product_hook2' );
	add_action( 'edd_order_status_cancelled', 'um_edd_per_product_hook2' );
	add_action( 'edd_order_status_on-hold', 'um_edd_per_product_hook2' );
	function um_edd_per_product_hook2( $order_id ) {
		global $ultimatemember;
		$order = new WC_Order( $order_id );
		$user_id = (int)$order->user_id;
		$items = $order->get_items();
		foreach ($items as $item) {
			$id = $item['product_id'];
			if ( get_post_meta( $id, '_um_edd_download_role', true ) != '' ) {
				um_fetch_user( $user_id );
				$ultimatemember->user->set_role( 'member' );
			}
		}
		return $order_id;
	}
	
	/***
	***	@When any product is bought
	***/
	add_action( 'edd_order_status_completed', 'um_edd_sync_role_completed' );
	function um_edd_sync_role_completed( $order_id ) {
		global $ultimatemember;
		
		$role = um_get_option('edd_oncomplete_role');
		if ( !$role )
			return;
		
		$order = new WC_Order( $order_id );
		$user_id = (int)$order->user_id;
		um_fetch_user( $user_id );
		
		$ultimatemember->user->set_role( $role );
		
	}
	
	/***
	***	@When any product is cancelled
	***/
	add_action( 'edd_order_status_pending', 'um_edd_sync_role_incompleted' );
	add_action( 'edd_order_status_processing', 'um_edd_sync_role_incompleted' );
	add_action( 'edd_order_status_failed', 'um_edd_sync_role_incompleted' );
	add_action( 'edd_order_status_refunded', 'um_edd_sync_role_incompleted' );
	add_action( 'edd_order_status_cancelled', 'um_edd_sync_role_incompleted' );
	add_action( 'edd_order_status_on-hold', 'um_edd_sync_role_incompleted' );
	function um_edd_sync_role_incompleted( $order_id ) {
		global $ultimatemember;
		
		$role = um_get_option('edd_oncomplete_role');
		if ( !$role )
			return;
		
		$order = new WC_Order( $order_id );
		$user_id = (int)$order->user_id;
		um_fetch_user( $user_id );
		
		$ultimatemember->user->set_role( 'member' );
		
	}