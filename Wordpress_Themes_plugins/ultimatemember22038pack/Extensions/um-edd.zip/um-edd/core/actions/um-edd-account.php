<?php

	/***
	***	@hook before edd update address
	***/
	add_action('template_redirect', 'um_edd_pre_update', 1 );
	function um_edd_pre_update() {
		global $wp, $ultimatemember;
		
		if ( isset( $_POST['save_address'] ) && get_query_var('um_tab') == 'billing' ) {
			$wp->query_vars['edit-address'] = 'billing';
		}
		
		//if ( wc_has_notice( __( 'Address changed successfully.', 'um-edd' ) ) ) {
			//wc_clear_notices();
			//$url = $ultimatemember->account->tab_link( 'billing' );
			//exit( wp_redirect( add_query_arg('updated','edit-billing', $url ) ) );
		//}
		
	}
	
	/***
	***	@hook in account update
	***/
	add_action('um_post_account_update', 'um_edd_account_update', 1 );
	function um_edd_account_update() {
		global $wp;
		
		if ( isset( $_POST['save_address'] ) && get_query_var('um_tab') == 'billing' ) {
			exit( wp_redirect( add_query_arg('updated','edit-billing') ) );
		}
		
	}

	/**
 * Process Profile Updater Form
 *
 * Processes the profile updater form by updating the necessary fields
 *
 * @since 1.4
 * @author Sunny Ratilal
 * @param array $data Data sent from the profile editor
 * @return void
 */
function um_edd_process_profile_editor_updates( $data ) {

	// Profile field change request
	if ( empty( $_POST['save_address'] ) && !is_user_logged_in() ) {
		return false;
	}

	// Pending users can't edit their profile
	if ( edd_user_pending_verification() ) {
		return false;
	}

	// Nonce security
	if ( ! wp_verify_nonce( $data['edd_profile_editor_nonce'], 'edd-profile-editor-nonce' ) ) {
		return false;
	}
	//print_r($_POST); die();
	$user_id       = get_current_user_id();
	$old_user_data = get_userdata( $user_id );

	$display_name = isset( $data['edd_display_name'] ) ? sanitize_text_field( $data['edd_display_name'] ) : $old_user_data->display_name;
	$first_name   = isset( $data['edd_first_name'] ) ? sanitize_text_field( $data['edd_first_name'] ) : $old_user_data->first_name;
	$last_name    = isset( $data['edd_last_name'] ) ? sanitize_text_field( $data['edd_last_name'] ) : $old_user_data->last_name;
	$email        = isset( $data['edd_email'] ) ? sanitize_email( $data['edd_email'] ) : $old_user_data->user_email;
	$line1        = ( isset( $data['edd_address_line1'] ) ? sanitize_text_field( $data['edd_address_line1'] ) : '' );
	$line2        = ( isset( $data['edd_address_line2'] ) ? sanitize_text_field( $data['edd_address_line2'] ) : '' );
	$city         = ( isset( $data['edd_address_city'] ) ? sanitize_text_field( $data['edd_address_city'] ) : '' );
	$state        = ( isset( $data['edd_address_state'] ) ? sanitize_text_field( $data['edd_address_state'] ) : '' );
	$zip          = ( isset( $data['edd_address_zip'] ) ? sanitize_text_field( $data['edd_address_zip'] ) : '' );
	$country      = ( isset( $data['edd_address_country'] ) ? sanitize_text_field( $data['edd_address_country'] ) : '' );

	$userdata = array(
		'ID'           => $user_id,
		'first_name'   => $first_name,
		'last_name'    => $last_name,
		'display_name' => $display_name,
		'user_email'   => $email
	);


	$address = array(
		'line1'    => $line1,
		'line2'    => $line2,
		'city'     => $city,
		'state'    => $state,
		'zip'      => $zip,
		'country'  => $country
	);

	do_action( 'edd_pre_update_user_profile', $user_id, $userdata );

	// New password
	if ( ! empty( $data['edd_new_user_pass1'] ) ) {
		if ( $data['edd_new_user_pass1'] !== $data['edd_new_user_pass2'] ) {
			edd_set_error( 'password_mismatch', __( 'The passwords you entered do not match. Please try again.', 'easy-digital-downloads' ) );
		} else {
			$userdata['user_pass'] = $data['edd_new_user_pass1'];
		}
	}

	// Make sure the new email doesn't belong to another user
	if( $email != $old_user_data->user_email ) {
		// Make sure the new email is valid
		if( ! is_email( $email ) ) {
			edd_set_error( 'email_invalid', __( 'The email you entered is invalid. Please enter a valid email.', 'easy-digital-downloads' ) );
		}

		// Make sure the new email doesn't belong to another user
		if( email_exists( $email ) ) {
			edd_set_error( 'email_exists', __( 'The email you entered belongs to another user. Please use another.', 'easy-digital-downloads' ) );
		}
	}

	// Check for errors
	$errors = edd_get_errors();

	if( $errors ) {
		// Send back to the profile editor if there are errors
		//wp_redirect( $data['edd_redirect'] );
		wp_redirect( add_query_arg('updated','edit-billing'));
		edd_die();
	}

	// Update the user
	$meta    = update_user_meta( $user_id, '_edd_user_address', $address );
	$updated = wp_update_user( $userdata );

	if ( $updated ) {
		do_action( 'edd_user_profile_updated', $user_id, $userdata );
		if ( isset( $_POST['save_address'] ) ) {
			exit( wp_redirect( add_query_arg('updated','edit-billing') ) );
		}
		//wp_redirect( add_query_arg( 'updated', 'true', $data['edd_redirect'] ) );
		//edd_die();
	}
}
add_action( 'edd_edit_user_profile', 'um_edd_process_profile_editor_updates' );
remove_action( 'edd_edit_user_profile', 'edd_process_profile_editor_updates' );