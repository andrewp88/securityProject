<?php
	
	/* new blog post */
	/*add_action('publish_post', 'um_activity_new_blog_post');
	function um_activity_new_blog_post( $post_id ) {
		if (defined('DOING_AUTOSAVE') && DOING_AUTOSAVE) return;
		if ( get_post_type( $post_id ) != 'post' ) return;
		if ( !isset( $_POST['original_post_status'] ) ) return;

		if( ( $_POST['post_status'] == 'publish' ) && ( $_POST['original_post_status'] == 'publish' ) ) return;

		global $um_activity;
		if ( !um_get_option('activity-new-post') )
			return;
		
		$post = get_post( $post_id );
		$user_id = $post->post_author;

		um_fetch_user( $user_id );
		$author_name = um_user('display_name');
		$author_profile = um_user_profile_url();
		
		if (has_post_thumbnail( $post_id ) ) {
			$image = wp_get_attachment_image_src( get_post_thumbnail_id( $post->ID ), 'large' );
			$post_image = '<span class="post-image"><img src="'. $image[0] . '" alt="" title="" class="um-activity-featured-img" /></span>';
		} else {
			$post_image = '';
		}
		
		if ( $post->post_content ) {
			$post_excerpt = '<span class="post-excerpt">' . wp_trim_words( $post->post_content, $num_words = 25, $more = null ) . '</span>';
		} else {
			$post_excerpt = '';
		}

		$um_activity->api->save(
			array(
				'template' => 'new-post',
				'wall_id' => $user_id,
				'related_id' => $post_id,
				'author' => $user_id,
				'author_name' => $author_name,
				'author_profile' => $author_profile,
				'post_title' => '<span class="post-title">' . $post->post_title . '</span>',
				'post_url' => get_permalink( $post_id ),
				'post_excerpt' => $post_excerpt,
				'post_image' => $post_image,
			)
		);
		
    }*/
	
	/* new product */
	add_action('save_post', 'um_activity_new_edd_download', 99999, 1 );
	function um_activity_new_edd_download( $post_id ) {
		if (defined('DOING_AUTOSAVE') && DOING_AUTOSAVE) return;
		if ( get_post_type( $post_id ) != 'download' || get_post_status( $post_id ) != 'publish' ) return;
		
		global $um_activity;
		
		if ( !um_get_option('activity-new-product') )
			return;
		
		$post = get_post($post_id);
		if( $post->post_modified_gmt != $post->post_date_gmt ) return;

		if ( !isset( $_POST['original_post_status'] ) ) return;
		if( ( $_POST['post_status'] == 'publish' ) && ( $_POST['original_post_status'] == 'publish' ) ) return;
		
		$user_id = $post->post_author;

		um_fetch_user( $user_id );
		$author_name = um_user('display_name');
		$author_profile = um_user_profile_url();
		
		if (has_post_thumbnail( $post_id ) ) {
			$image = wp_get_attachment_image_src( get_post_thumbnail_id( $post->ID ), 'large' );
			$post_image = '<span class="post-image"><img src="'. $image[0] . '" alt="" title="" class="um-activity-featured-img" /></span>';
		} else {
			$post_image = '';
		}
		
		if ( $post->post_excerpt ) {
			$post_excerpt = '<span class="post-excerpt">' . strip_tags( apply_filters( 'edd_short_description', $post->post_excerpt ) ) . '</span>';
		} elseif ( $post->post_content ) {
			$post_excerpt = '<span class="post-excerpt">' . wp_trim_words( $post->post_content, $num_words = 25, $more = null ) . '</span>';
		} else  {
			$post_excerpt = '';
		}
		
		$um_activity->api->save(
			array(
				'template' => 'new-product',
				'wall_id' => $user_id,
				'author' => $user_id,
				'author_name' => $author_name,
				'author_profile' => $author_profile,
				'post_title' => '<span class="post-title">' . $post->post_title . '</span>',
				'post_url' => get_permalink( $post_id ),
				'post_excerpt' => $post_excerpt,
				'post_image' => $post_image,
				// 'price' => '<span class="post-price">' . edd_price( $post_id, false ) . '</span>',
			)
		);
		
    }