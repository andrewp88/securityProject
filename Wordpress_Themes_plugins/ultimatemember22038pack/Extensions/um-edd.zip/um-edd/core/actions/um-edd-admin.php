<?php
	
	/***
	***	@create role options
	***/
	add_action('um_admin_custom_role_metaboxes', 'um_edd_add_role_metabox');
	function um_edd_add_role_metabox( $action ){
		
		global $ultimatemember;
		
		$metabox = new UM_Admin_Metabox();
		$metabox->is_loaded = true;

		add_meta_box("um-admin-form-edd{" . um_edd_path . "}", __('Easy Digital Downloads','um-edd'), array(&$metabox, 'load_metabox_role'), 'um_role', 'normal', 'low');
		
	}
	
	/***
	***	@add options to Easy Digital Downloads product page
	***/
	add_action('um_admin_before_access_settings', 'um_edd_add_role_options', 50, 1);
	function um_edd_add_role_options( $metabox ) {
		global $ultimatemember;
		if ( get_post_type() == 'download' ) {
			
			$roles = array('' => __('None','um-edd') ) + $ultimatemember->query->get_roles( );
			
			$saved_r = (string)get_post_meta( get_the_ID(), '_um_edd_download_role', true );
			$saved_r = ( $saved_r ) ? $saved_r : '';
			
			?>
			
			<h4><?php _e('When this product is bought move user to this role:','um-edd'); ?></h4>
				
			<p>
				<select name="_um_edd_download_role" id="_um_edd_download_role">
				<?php foreach ( $roles as $k => $role ) { ?>
				<option value="<?php echo $k; ?>" <?php selected( $k, $saved_r ); ?>><?php echo $role; ?></option>
				<?php } ?>
				</select>
			</p>
	
			<?php
		}
	}