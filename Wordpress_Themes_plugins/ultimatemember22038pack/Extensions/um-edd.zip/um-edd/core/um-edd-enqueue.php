<?php

class UM_EDD_Enqueue {

	function __construct() {
	
		add_action('wp_enqueue_scripts',  array(&$this, 'wp_enqueue_scripts'), 9999);
	
	}

	function wp_enqueue_scripts(){
		
		//if ( !is_user_logged_in() ) return;

		wp_register_style('um_edd', um_edd_url . 'assets/css/um-edd.css' );
		wp_enqueue_style('um_edd');
		
		wp_register_script('um_edd', um_edd_url . 'assets/js/um-edd.js', '', '', true );
		wp_enqueue_script('um_edd');
		
	}
	
}