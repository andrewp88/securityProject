<?php

	/***
	***	@add tab for product reviews
	***/
	add_filter('um_profile_tabs', 'um_edd_add_tab', 800 );
	function um_edd_add_tab( $tabs ) {
		global $um_reviews;
		
		$tabs['downloads'] = array(
			'name' => __('Downloads','um-edd'),
			'icon' => 'um-faicon-shopping-cart'
		);
		
		/*$tabs['product-reviews'] = array(
			'name' => __('Product Reviews','um-edd'),
			'icon' => 'um-faicon-star'
		);*/
		
		return $tabs;
	}
	
	/***
	***	@add tabs based on user
	***/
	add_filter('um_user_profile_tabs', 'um_edd_user_add_tab', 1000 );
	function um_edd_user_add_tab( $tabs ) {
		
		if ( !is_user_logged_in() && um_get_option('edd_hide_downloads_tab') )
			unset( $tabs['downloads'] );
		
		if ( !um_user('edd_downloads_tab') )
			unset( $tabs['downloads'] );
		
		return $tabs;
		
	}