<?php
	
	/***
	***	@filter user permissions
	***/
	add_filter('um_user_permissions_filter', 'um_edd_user_permissions_filter', 10, 4);
	function um_edd_user_permissions_filter( $meta, $user_id ){
		
		if ( !isset( $meta['edd_downloads_tab'] ) )
			$meta['edd_downloads_tab'] = 1;
		
		if ( !isset( $meta['edd_account_orders'] ) )
			$meta['edd_account_orders'] = 1;
		
		if ( !isset( $meta['edd_account_billing'] ) )
			$meta['edd_account_billing'] = 1;
		
		return $meta;
	}