<?php

	/***
	***	@extend settings
	***/
	add_filter("redux/options/um_options/sections", 'um_edd_config', 9.520 );
	function um_edd_config($sections){
		global $ultimatemember, $um_edd;
		
		$sections[] = array(

			'subsection' => true,
			'title'      => __( 'EDD','um-edd'),
			'fields'     => array(

				array(
						'id'       		=> 'edd_oncomplete_role',
						'type'     		=> 'select',
						'select2'		=> array( 'allowClear' => 0, 'minimumResultsForSearch' => -1 ),
						'title'    		=> __( 'Assign this role to users when payment is completed','um-edd' ),
						'desc' 	   		=> __( 'Automatically set the user this role when a payment is completed.','um-edd' ),
						'default'  		=> '',
						'options' 		=> array('' => __('None','um-edd') ) + $ultimatemember->query->get_roles( ),
						'placeholder' 	=> __('Community role...','um-edd'),
				),
				
				array(
						'id'       		=> 'edd_hide_downloads_tab',
						'type'     		=> 'switch',
						'default'		=> 0,
						'title'   		=> __( 'Hide downloads tab from guests','um-edd' ),
						'desc' 	   		=> __('Enable this option If you do not want to show the downloads tab for guests.','um-edd'),
						'on'			=> __('Yes','um-edd'),
						'off'			=> __('No','um-edd'),
				)

			)

		);

		return $sections;
		
	}