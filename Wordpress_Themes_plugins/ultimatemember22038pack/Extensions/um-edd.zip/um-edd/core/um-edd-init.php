<?php

class UM_EDD_API {

	function __construct() {

		$this->plugin_inactive = false;
		
		add_action('init', array(&$this, 'plugin_check'), 1);
		
		add_action('init', array(&$this, 'init'), 1);

	}
	
	/***
	***	@Check plugin requirements
	***/
	function plugin_check(){
		
		if ( !class_exists('UM_API') ) {
			
			$this->add_notice( sprintf(__('The <strong>%s</strong> extension requires the Ultimate Member plugin to be activated to work properly. You can download it <a href="https://wordpress.org/plugins/ultimate-member">here</a>','um-edd'), um_edd_extension) );
			$this->plugin_inactive = true;
		
		} else if ( !class_exists( 'Easy_Digital_Downloads' ) ) {
			
			$this->add_notice( sprintf(__('Easy Digital Downloads must be activated before you can use %s.','um-edd'), um_edd_extension ) );
			$this->plugin_inactive = true;
			
		} else if ( !version_compare( ultimatemember_version, um_edd_requires, '>=' ) ) {
			
			$this->add_notice( sprintf(__('The <strong>%s</strong> extension requires a <a href="https://wordpress.org/plugins/ultimate-member">newer version</a> of Ultimate Member to work properly.','um-edd'), um_edd_extension) );
			$this->plugin_inactive = true;
		
		}
		
	}
	
	/***
	***	@Add notice
	***/
	function add_notice( $msg ) {
		
		if ( !is_admin() ) return;
		
		echo '<div class="error"><p>' . $msg . '</p></div>';
		
	}
	
	/***
	***	@Init
	***/
	function init() {
		
		if ( $this->plugin_inactive ) return;

		// Required classes
		require_once um_edd_path . 'core/um-edd-api.php';
		require_once um_edd_path . 'core/um-edd-enqueue.php';
		
		$this->api = new UM_EDD_Core();
		$this->enqueue = new UM_EDD_Enqueue();
		
		// Actions
		require_once um_edd_path . 'core/actions/um-edd-account.php';
		require_once um_edd_path . 'core/actions/um-edd-ajax.php';
		require_once um_edd_path . 'core/actions/um-edd-tabs.php';
		require_once um_edd_path . 'core/actions/um-edd-admin.php';
		require_once um_edd_path . 'core/actions/um-edd-order.php';
		require_once um_edd_path . 'core/actions/um-activity-actions.php';
		
		// Filters
		require_once um_edd_path . 'core/filters/um-edd-account.php';
		require_once um_edd_path . 'core/filters/um-edd-fields.php';
		require_once um_edd_path . 'core/filters/um-edd-reviews.php';
		require_once um_edd_path . 'core/filters/um-edd-tabs.php';
		require_once um_edd_path . 'core/filters/um-edd-permissions.php';
		require_once um_edd_path . 'core/filters/um-edd-settings.php';

	}
}

$um_edd = new UM_EDD_API();