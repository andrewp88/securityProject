<?php
/*
Plugin Name: Ultimate Member - Easy Digital Downloads
Plugin URI: http://ultimate-member-ext.opentuteplus.com/
Description: Integrates your Easy Digital Downloads store with Ultimate Member.
Author: Kishore Sahoo
Author URI: http://iamkisho.re
Version: 1.0.1
Requires at least: WP 3.8, Ultimate Member 1.3.11
Tested up to: WP 4.4.2, Ultimate Member 1.3.44, Easy Digital Downloads 2.5.10
Text Domain: um-edd
Domain Path: /languages/

Copyright: 2015 Kishore Sahoo
License: GNU General Public License v3.0
License URI: http://www.gnu.org/licenses/gpl-3.0.html
*/

	require_once(ABSPATH.'wp-admin/includes/plugin.php');
	
	$plugin_data = get_plugin_data( __FILE__ );

	define('um_edd_url',plugin_dir_url(__FILE__ ));
	define('um_edd_path',plugin_dir_path(__FILE__ ));
	define('um_edd_plugin', plugin_basename( __FILE__ ) );
	define('um_edd_extension', $plugin_data['Name'] );
	define('um_edd_version', $plugin_data['Version'] );
	
	define('um_edd_requires', '1.3.26');
	
	$plugin = um_edd_plugin;

	/***
	***	@Init
	***/
	require_once um_edd_path . 'core/um-edd-init.php';

	function um_edd_plugins_loaded() {
		load_plugin_textdomain( 'um-edd', false, dirname( plugin_basename( __FILE__ ) ) . '/languages/' );
	}
	add_action( 'plugins_loaded', 'um_edd_plugins_loaded', 0 );
	
	/* Licensing */