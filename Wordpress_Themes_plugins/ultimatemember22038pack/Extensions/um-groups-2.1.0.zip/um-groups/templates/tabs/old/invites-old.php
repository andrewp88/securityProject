<table id="um_groups_invite_members" data-group-status="invite" class="display">
        <thead>
            <tr>
                <th></th>
            </tr>
        </thead>
        <tbody>
            
        </tbody>
        <tfoot>
            <tr>
                <th></th>
            </tr>
        </tfoot>
</table>