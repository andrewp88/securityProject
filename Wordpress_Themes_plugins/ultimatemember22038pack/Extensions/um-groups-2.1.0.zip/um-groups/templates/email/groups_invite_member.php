Hi {group_invitation_guest_name},

{group_invitation_host_name} has invited you to join {group_name}. 
To confirm/reject this invitation please click the following link: {group_url}